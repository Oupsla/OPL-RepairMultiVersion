package com.durieudufaux.demoproject;

public class B {
	
	private A a;
	
	public B(A a){
		this.a = a;
	}
	
	public int methodBTuna() throws Exception{
		System.out.println("content of methodBTuna v3");
		return a.methodAFoo();
	}
	
	public int methodBJam() throws Exception{
		System.out.println("content of methodBJam v3");
		throw new Exception("MethodBJam v2 & v3 is broken");
	}

}
