package com.durieudufaux.demoproject;

public class A {

	public A(){
		
	}
	
	public int methodAFoo() throws Exception{
		System.out.println("content of methodAFoo v3");
		throw new Exception("MethodAFoo v3 is broken");
	}
	
	public int methodABar(B b) throws Exception{
		System.out.println("content of methodABar v3");
		return b.methodBJam();
	}
}
