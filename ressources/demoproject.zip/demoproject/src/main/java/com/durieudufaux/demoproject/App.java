package com.durieudufaux.demoproject;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws Exception
    {
    	A a = new A();
    	B b = new B(a);
    	
    	b.methodBTuna();
    	a.methodABar(b);
    }
}
